a = 10
b = 2
if a > b :
    #inside if
    print('A > B')
    print('inside if')
    print('Still inside if')
else:
    print('B > A')
    print('inside else')
    print('Still inside else')
################################################################################    
name ='python programming'
print(name.startswith(('p')))

if name.startswith('p'):
    print("its python")
    print('inside if')
else:
    print('its unix')
    print('inside else')
################################################################################
if name.endswith('g'):
    print('string is ending with g')
    print('inside if')
else:
    print('string is something else')
    print('inside else')
################################################################################    
aname = 'python'
if aname.isupper():
    print('string is upper')
else:
    print('string is lower')
    
name ='python programming'
if  len(name) == 18:
    print('its 18 characters')
else:
    print('something else')
################################################################################