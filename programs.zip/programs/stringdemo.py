


name = 'python programming'
print(name)
print('I love',name)
print(10,20,30)
# string slicing - extract some portion of the string
# string[start:stop:incremental]
name = 'python programming'
print(name[0])
print(name[1])
print(name[0:4])
print(name[7:10])
print(name[:])  # python programming
print(name[0:18:1])
print(name[0:18])
print(name[0:18:2])
print(name[1:18:2])
print(name[7:16:3])
print(name[::])   # python programming
print(name[-1])
print(name[-2])
print(name[-5:-2])
print(name[::-1])

name = 'python programming'
print(len(name))
print(len('unix'))
print(len(name.replace(' ','')))
print(name.capitalize())
print(name.title())

print(name.center(20))
print(name.center(20,"*"))

print(name.count('p'))
print(name.count('gram'))

print(name.endswith('g'))
print(name.endswith('a'))
print(name.startswith('p'))
print(name.startswith('a'))

print(name.isupper())
print(name.islower())
print(name.isalnum())

output = name.split(' ')
print(output)

print(name.replace('python', 'ru\'by'))
print(name)
# strip() will remove the whitespace from both the ends
aname = ' python  '
print(len(aname))
print(len(aname.strip())) #
print(len(aname.lstrip())) #
print(len(aname.rstrip())) #


aname = "I love {} and {}"
print(aname.format('unix','java'))
print(aname.format(1,2))


aname = "I love {} and {} and {} and {}"
print(aname.format('unix','java','spark','hadoop'))
print(aname.format(1,2))

aname = "I love {} and {} and {} and {} and {} and {}"
values  = (1,2,3,4,5,6)
print(aname.format(*values))

name = 'python'
print(name.center(4))
print(name.center(4,"*"))


# string concatenation
first = 'python'
second = 'programming'
final = first + second
print(final)














